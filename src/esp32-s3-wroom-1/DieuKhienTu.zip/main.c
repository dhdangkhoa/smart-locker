#include <Arduino.h>
#include <stdint.h>
#include <stdbool.h>
#include <ESP32Servo.h> // Thư viện điều khiển Servo cho ESP32

// ĐỊNH NGHĨA CHÂN GPIO 

#define PIN_SW_DOOR_1      38   // LOW: Cửa 1 mở     | HIGH: Cửa 1 đóng
#define PIN_SW_DOOR_2      39   // LOW: Cửa 2 mở     | HIGH: Cửa 2 đóng
#define PIN_SW_PARCEL_1    22   // LOW: Ngăn 1 trống | HIGH: Có hàng
#define PIN_SW_PARCEL_2    23   //cLOW: Ngăn 2 trống | HIGH: Có hàng

#define PIN_LED_SLOT_1     25   // HIGH: LED 1 sáng | LOW: Tắt
#define PIN_LED_SLOT_2     2    // HIGH: LED 2 sáng  | LOW: LED 2 tắt

#define PIN_BTN_PWR        1    // Nút nguồn (LOW: Nhấn)
#define PIN_BTN_QR1        14   // Nút QR1   (LOW: Nhấn)
#define PIN_BTN_QR2        21   // Nút QR2   (LOW: Nhấn)
#define PIN_BTN_QR3        26   // Nút QR3

// Chân điều khiển Servo và Buzzer
#define PIN_SERVO_1        15   // Chân tín hiệu Servo khóa ngăn 1
#define PIN_SERVO_2        13   // Chân tín hiệu Servo khóa ngăn 2
#define PIN_BUZZER         12   // Chân điều khiển còi Buzzer

#define DEBOUNCE_TIME_MS   30     // Chống dội 30ms
#define DOOR_OPEN_TIMEOUT  10000  // Chờ mở cửa tối đa 10 giây

// GÓC QUAY CỦA SERVO
#define SERVO_LOCK_ANGLE   0      // Góc đóng chốt khóa
#define SERVO_UNLOCK_ANGLE 90     // Góc mở chốt khóa

// CẤU TRÚC DỮ LIỆU TRẠNG THÁI
typedef enum {
    DOOR_CLOSED = 0,
    DOOR_OPEN   = 1
} DoorState_t;

typedef enum {
    SLOT_EMPTY    = 0,
    SLOT_RESERVED = 1,
    SLOT_OCCUPIED = 2,
    SLOT_FAULT    = 3
} SlotState_t;

typedef struct {
    uint8_t     slot_id;      // 1 hoặc 2
    SlotState_t state;        // EMPTY, RESERVED, OCCUPIED, FAULT
    DoorState_t door;         // DOOR_OPEN hoặc DOOR_CLOSED
    bool        has_parcel;   // true: Có hàng, false: Trống
    bool        led_on;       // true: LED sáng, false: LED tắt
} SlotData_t;

SlotData_t g_slots[2] = {
    { 1, SLOT_EMPTY, DOOR_CLOSED, false, false },
    { 2, SLOT_EMPTY, DOOR_CLOSED, false, false }
};

// Khai báo đối tượng Servo
Servo servo_slot_1;
Servo servo_slot_2;

// CÁC HÀM ĐIỀU KHIỂN BUZZER & SERVO

void Buzzer_Beep(uint16_t duration_ms) {
    digitalWrite(PIN_BUZZER, HIGH);
    delay(duration_ms);
    digitalWrite(PIN_BUZZER, LOW);
}

void Servo_ControlInit(void) {
    pinMode(PIN_BUZZER, OUTPUT);
    digitalWrite(PIN_BUZZER, LOW);

    servo_slot_1.attach(PIN_SERVO_1);
    servo_slot_2.attach(PIN_SERVO_2);
    
    servo_slot_1.write(SERVO_LOCK_ANGLE);
    servo_slot_2.write(SERVO_LOCK_ANGLE);
}

void Servo_Unlock(uint8_t slot_id) {
    if (slot_id == 1) {
        servo_slot_1.write(SERVO_UNLOCK_ANGLE);
        Serial.printf("-> Mo khoa Servo Ngan 1 (Goc %d do)\n", SERVO_UNLOCK_ANGLE);
    } else if (slot_id == 2) {
        servo_slot_2.write(SERVO_UNLOCK_ANGLE);
        Serial.printf("-> Mo khoa Servo Ngan 2 (Goc %d do)\n", SERVO_UNLOCK_ANGLE);
    }
    Buzzer_Beep(100);
}

void Servo_Lock(uint8_t slot_id) {
    if (slot_id == 1) {
        servo_slot_1.write(SERVO_LOCK_ANGLE);
        Serial.printf("-> Khoa chot Servo Ngan 1 (Goc %d do)\n", SERVO_LOCK_ANGLE);
    } else if (slot_id == 2) {
        servo_slot_2.write(SERVO_LOCK_ANGLE);
        Serial.printf("-> Khoa chot Servo Ngan 2 (Goc %d do)\n", SERVO_LOCK_ANGLE);
    }
    Buzzer_Beep(50);
}

// CÁC HÀM ĐỌC CẢM BIẾN & ĐIỀU KHIỂN LED

void Sensor_Init(void) {
    pinMode(PIN_SW_DOOR_1, INPUT);
    pinMode(PIN_SW_DOOR_2, INPUT);
    pinMode(PIN_SW_PARCEL_1, INPUT);
    pinMode(PIN_SW_PARCEL_2, INPUT);

    pinMode(PIN_BTN_PWR, INPUT_PULLUP);
    pinMode(PIN_BTN_QR1, INPUT_PULLUP);
    pinMode(PIN_BTN_QR2, INPUT_PULLUP);
    pinMode(PIN_BTN_QR3, INPUT_PULLUP);

    pinMode(PIN_LED_SLOT_1, OUTPUT);
    pinMode(PIN_LED_SLOT_2, OUTPUT);
    digitalWrite(PIN_LED_SLOT_1, LOW);
    digitalWrite(PIN_LED_SLOT_2, LOW);

    Servo_ControlInit();
}

static int Sensor_ReadPinDebounced(uint8_t pin) {
    int first_read = digitalRead(pin);
    delay(DEBOUNCE_TIME_MS);
    int second_read = digitalRead(pin);
    return (first_read == second_read) ? second_read : digitalRead(pin);
}

DoorState_t Sensor_GetDoorState(uint8_t slot_id) {
    uint8_t pin = (slot_id == 1) ? PIN_SW_DOOR_1 : PIN_SW_DOOR_2;
    return (Sensor_ReadPinDebounced(pin) == LOW) ? DOOR_OPEN : DOOR_CLOSED;
}

bool Sensor_HasParcel(uint8_t slot_id) {
    uint8_t pin = (slot_id == 1) ? PIN_SW_PARCEL_1 : PIN_SW_PARCEL_2;
    return (Sensor_ReadPinDebounced(pin) == HIGH);
}

void Sensor_SetSlotLED(uint8_t slot_id, bool turn_on) {
    uint8_t led_pin = (slot_id == 1) ? PIN_LED_SLOT_1 : PIN_LED_SLOT_2;
    digitalWrite(led_pin, turn_on ? HIGH : LOW);
    g_slots[slot_id - 1].led_on = turn_on;
}

void Sensor_UpdateAllSlots(void) {
    for (uint8_t i = 0; i < 2; i++) {
        uint8_t slot_id = i + 1;
        g_slots[i].door       = Sensor_GetDoorState(slot_id);
        g_slots[i].has_parcel = Sensor_HasParcel(slot_id);
        g_slots[i].state      = g_slots[i].has_parcel ? SLOT_OCCUPIED : SLOT_EMPTY;
        Sensor_SetSlotLED(slot_id, g_slots[i].has_parcel);
    }
}

uint8_t Sensor_FindLowestEmptySlot(void) {
    Sensor_UpdateAllSlots();
    for (uint8_t i = 0; i < 2; i++) {
        if (!g_slots[i].has_parcel) {
            return g_slots[i].slot_id;
        }
    }
    return 0;
}

bool Sensor_WaitForDoorState(uint8_t slot_id, DoorState_t target_state, uint32_t timeout_ms) {
    unsigned long start_time = millis();
    while (true) {
        Sensor_UpdateAllSlots();

        if (Sensor_GetDoorState(slot_id) == target_state) {
            g_slots[slot_id - 1].door = target_state;
            return true;
        }
        if (timeout_ms > 0 && (millis() - start_time >= timeout_ms)) {
            g_slots[slot_id - 1].state = SLOT_FAULT;
            return false;
        }
        delay(50);
    }
}

bool Sensor_IsButtonPressed(uint8_t btn_pin) {
    if (digitalRead(btn_pin) == LOW) {
        delay(DEBOUNCE_TIME_MS);
        if (digitalRead(btn_pin) == LOW) {
            while (digitalRead(btn_pin) == LOW) {
                delay(10);
            }
            return true;
        }
    }
    return false;
}

void Test_RunSlotDelivery(uint8_t qr_button_num) {
    Serial.printf("\nBan vua nhan nut QR%d!\n", qr_button_num);
    Buzzer_Beep(200);

    uint8_t target_slot = Sensor_FindLowestEmptySlot();

    if (target_slot == 0) {
        Serial.println("Ca 2 ngan deu da CO HANG! Het ngan trong!\n");
        for(int i = 0; i < 3; i++) {
            Buzzer_Beep(100);
            delay(100);
        }
        return;
    }

    Serial.printf("He thong chon NGAN SO %d.\n", target_slot);
    Servo_Unlock(target_slot);

    Serial.printf("Dang cho ban mo CUA %d trong 10s...\n", target_slot);

    if (Sensor_WaitForDoorState(target_slot, DOOR_OPEN, DOOR_OPEN_TIMEOUT)) {
        Serial.printf("-> Da xac nhan CUA %d MO! Hay gat cong tac HANG %d sang 'CO HANG', roi gat CUA %d ve 'DONG'...\n",
                      target_slot, target_slot, target_slot);

        Sensor_WaitForDoorState(target_slot, DOOR_CLOSED, 0);
        Servo_Lock(target_slot);
        Serial.printf("Da xac nhan CUA %d DONG! Khoa chot ngan %d.\n", target_slot, target_slot);

        Sensor_UpdateAllSlots();
        if (Sensor_HasParcel(target_slot)) {
            Serial.printf("Giao hang vao NGAN %d THANH CONG! LED %d SANG.\n\n", target_slot, target_slot);
            Buzzer_Beep(150);
            delay(100);
            Buzzer_Beep(150);
        } else {
            Serial.printf("NGAN %d van TRONG sau khi dong cua! LED %d TAT.\n\n", target_slot, target_slot);
            Buzzer_Beep(500);
        }
    } else {
        Serial.printf("Qua 10 giay khong mo CUA %d! Huy giao dich, khoa lai chot.\n\n", target_slot);
        Servo_Lock(target_slot);
        Buzzer_Beep(400);
    }
}

// CHƯƠNG TRÌNH CHÍNH (setup & loop)

DoorState_t prev_door[2];
bool        prev_parcel[2];

void setup() {
    Serial.begin(115200);
    Sensor_Init();
    Sensor_UpdateAllSlots();

    for (int i = 0; i < 2; i++) {
        prev_door[i]   = g_slots[i].door;
        prev_parcel[i] = g_slots[i].has_parcel;
    }

    Serial.println("  HE THONG SMART LOCKER - CHUẨN ESP32 (0-39)");

    for (int i = 0; i < 2; i++) {
        Serial.printf("Ngan %d ban dau -> Cua: %s | Hang: %s | LED %d: %s\n",
                      i + 1,
                      (g_slots[i].door == DOOR_OPEN) ? "DANG MO (LOW)" : "DANG DONG (HIGH)",
                      g_slots[i].has_parcel ? "CO HANG (HIGH)" : "TRONG (LOW)",
                      i + 1,
                      g_slots[i].led_on ? "SANG" : "TAT");
    }
}

void loop() {
    Sensor_UpdateAllSlots();

    for (int i = 0; i < 2; i++) {
        uint8_t slot_id = i + 1;

        if (g_slots[i].door != prev_door[i]) {
            prev_door[i] = g_slots[i].door;
            Serial.printf("Ngan %d -> %s\n",
                          slot_id,
                          (g_slots[i].door == DOOR_OPEN) ? "CUA MO (LOW)" : "CUA DONG (HIGH)");
        }

        if (g_slots[i].has_parcel != prev_parcel[i]) {
            prev_parcel[i] = g_slots[i].has_parcel;
            Serial.printf("Ngan %d -> %s | LED %d: %s\n",
                          slot_id,
                          g_slots[i].has_parcel ? "CO HANG (HIGH)" : "TRONG (LOW)",
                          slot_id,
                          g_slots[i].led_on ? "SANG" : "TAT");
        }
    }

    // Kiểm tra các nút bấm QR
    if (Sensor_IsButtonPressed(PIN_BTN_QR1)) {
        Test_RunSlotDelivery(1);
        for (int i = 0; i < 2; i++) { prev_door[i] = g_slots[i].door; prev_parcel[i] = g_slots[i].has_parcel; }
    }
    if (Sensor_IsButtonPressed(PIN_BTN_QR2)) {
        Test_RunSlotDelivery(2);
        for (int i = 0; i < 2; i++) { prev_door[i] = g_slots[i].door; prev_parcel[i] = g_slots[i].has_parcel; }
    }
    if (Sensor_IsButtonPressed(PIN_BTN_QR3)) {
        Test_RunSlotDelivery(3);
        for (int i = 0; i < 2; i++) { prev_door[i] = g_slots[i].door; prev_parcel[i] = g_slots[i].has_parcel; }
    }

    delay(20);
}